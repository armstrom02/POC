import { Component, OnInit } from '@angular/core';
import { DbconnectService } from '../dbconnect.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {


  private usertoken;
  

  constructor(private auth: DbconnectService) { }

  ngOnInit() {

    this.usertoken = (sessionStorage.getItem("token"));
    console.log(this.usertoken);
  }


  fetchdata(token) {
    this.auth.get_user(token).subscribe(response => {
       
        console.log(response);

    })

  }


}



