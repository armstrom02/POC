import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';
import { appRoutes } from './app.route';
import { DbconnectService } from './dbconnect.service';
import { HttpModule } from '@angular/http';



@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,

  ],
  imports: [
    BrowserModule,
    HttpModule,    
    RouterModule.forRoot(appRoutes)
  ],
  providers: [DbconnectService],
  bootstrap: [AppComponent]
})
export class AppModule { }
