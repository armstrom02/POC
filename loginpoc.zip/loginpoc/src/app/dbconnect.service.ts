import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Headers,RequestOptions } from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()
export class DbconnectService {

  constructor(private http : Http) { }
  private myroute = "192.168.14.111:8080/";

  create_user(user){
    let headers = new Headers({'Content-Type':'application/json'});
    let options = new RequestOptions({headers: headers});
    this.http.post('http://'+this.myroute,user,options).subscribe();
  }
  
  login_user(user,password){
    let headers = new Headers({'Content-Type':'application/json'});
    let options = new RequestOptions({headers: headers});
    let credentials:object ={username:user,password:password}
     return this.http.post('http://'+this.myroute+'demo/login',credentials,options).map((res:Response)=>res.json());
  }

  get_user(token){
    let headers = new Headers({'Authorization':token});
    let options = new RequestOptions({headers: headers});
     return this.http.get('http://'+this.myroute+'demo/test',options).map((res:Response)=>res.json());
  }



  
}

