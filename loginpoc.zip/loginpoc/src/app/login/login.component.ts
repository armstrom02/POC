import { Component, OnInit } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DbconnectService } from '../dbconnect.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private auth: DbconnectService, private router: Router) { }

  ngOnInit() {
  }

  loginfn(username, password) {
    if (username.length != 0 && password.length != 0) {
      this.auth.login_user(username, password).subscribe(response => {
        if (response.status == "SUCCESS") {
          sessionStorage.setItem("token", response.data.token);
        this.router.navigate(['Home']);
        }
        else alert("password is wrong")
      })
    }
    else alert("field id empty");
  }


}


