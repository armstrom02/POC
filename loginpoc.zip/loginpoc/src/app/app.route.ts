import { RouterModule,Routes} from '@angular/router';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { HomeComponent } from './home/home.component';


export const appRoutes: Routes = [
    
     { path: '', component: LoginComponent },
     { path: 'Home', component: HomeComponent },
     { path: 'login', component: LoginComponent },
     { path: '',redirectTo: 'Home', pathMatch: 'full' }
  ];